"""
database.py — Operaciones con Supabase (PostgreSQL)
Guarda señales, trades abiertos y resultados del paper trading
"""

import os
import logging
from datetime import datetime
from typing import Optional
import pytz

logger = logging.getLogger(__name__)

# Importación lazy para no romper si no está instalado
try:
    from supabase import create_client, Client
    SUPABASE_OK = True
except ImportError:
    SUPABASE_OK = False
    logger.warning("supabase-py no instalado — modo sin base de datos")


def get_client() -> Optional[object]:
    """
    Crea y retorna el cliente Supabase.
    Retorna None si las variables de entorno no están configuradas.
    """
    if not SUPABASE_OK:
        return None

    url = os.environ.get('SUPABASE_URL')
    key = os.environ.get('SUPABASE_KEY')

    if not url or not key:
        logger.warning("SUPABASE_URL o SUPABASE_KEY no configurados")
        return None

    try:
        return create_client(url, key)
    except Exception as e:
        logger.error(f"Error conectando a Supabase: {e}")
        return None


# ══════════════════════════════════════════════════════════
# SEÑALES
# ══════════════════════════════════════════════════════════

def guardar_señal(estrategia: str, ticker: str, direccion: str,
                   precio_entrada: float, bb_up: float, bb_mid: float,
                   adx: float, recorrido: float, size: float,
                   factor_estacional: float, ratio_adr: float,
                   sl: float, notas: str = '') -> Optional[dict]:
    """
    Guarda una señal detectada en la tabla 'señales'.
    """
    client = get_client()
    ahora = datetime.now(pytz.UTC).isoformat()

    datos = {
        'timestamp':         ahora,
        'estrategia':        estrategia,
        'ticker':            ticker,
        'direccion':         direccion,
        'precio_entrada':    round(precio_entrada, 3),
        'bb_up':             round(bb_up, 3),
        'bb_mid':            round(bb_mid, 3),
        'adx':               round(adx, 2),
        'recorrido_cts':     round(recorrido, 3),
        'size':              size,
        'factor_estacional': factor_estacional,
        'ratio_adr':         round(ratio_adr, 3),
        'sl_precio':         round(sl, 3),
        'estado':            'ABIERTA',
        'notas':             notas,
    }

    if client is None:
        logger.info(f"[SIN DB] Señal: {datos}")
        return datos

    try:
        res = client.table('señales').insert(datos).execute()
        logger.info(f"Señal guardada: {estrategia} {direccion} {ticker} @ {precio_entrada}")
        return res.data[0] if res.data else datos
    except Exception as e:
        logger.error(f"Error guardando señal: {e}")
        return None


# ══════════════════════════════════════════════════════════
# TRADES ABIERTOS
# ══════════════════════════════════════════════════════════

def abrir_trade(señal_id: str, estrategia: str, ticker: str,
                 direccion: str, entrada: float, sl: float,
                 trail_cts: float, size: float) -> Optional[dict]:
    """
    Registra un trade abierto en la tabla 'trades'.
    """
    client = get_client()
    ahora = datetime.now(pytz.UTC).isoformat()

    datos = {
        'señal_id':       señal_id,
        'timestamp_open': ahora,
        'estrategia':     estrategia,
        'ticker':         ticker,
        'direccion':      direccion,
        'precio_entrada': round(entrada, 3),
        'sl_inicial':     round(sl, 3),
        'trail_cts':      round(trail_cts, 3),
        'max_precio':     round(entrada, 3),  # se actualiza con cada barra
        'trail_actual':   round(sl, 3),
        'size':           size,
        'estado':         'ABIERTO',
        'barras':         0,
    }

    if client is None:
        logger.info(f"[SIN DB] Trade abierto: {datos}")
        return datos

    try:
        res = client.table('trades').insert(datos).execute()
        logger.info(f"Trade abierto: {estrategia} {direccion} {ticker} @ {entrada}")
        return res.data[0] if res.data else datos
    except Exception as e:
        logger.error(f"Error abriendo trade: {e}")
        return None


def actualizar_trade(trade_id: str, max_precio: float,
                      trail_actual: float, barras: int) -> bool:
    """
    Actualiza el trailing stop y el máximo precio de un trade abierto.
    """
    client = get_client()

    datos = {
        'max_precio':   round(max_precio, 3),
        'trail_actual': round(trail_actual, 3),
        'barras':       barras,
    }

    if client is None:
        logger.info(f"[SIN DB] Actualizar trade {trade_id}: {datos}")
        return True

    try:
        client.table('trades').update(datos).eq('id', trade_id).execute()
        return True
    except Exception as e:
        logger.error(f"Error actualizando trade {trade_id}: {e}")
        return False


def cerrar_trade(trade_id: str, precio_salida: float,
                  motivo: str, resultado_cts: float,
                  resultado_usd: float) -> bool:
    """
    Cierra un trade y registra el resultado.
    motivo: 'TP' | 'SL' | 'TRAIL' | 'TIEMPO' | 'ROLL'
    """
    client = get_client()
    ahora = datetime.now(pytz.UTC).isoformat()

    datos = {
        'timestamp_close': ahora,
        'precio_salida':   round(precio_salida, 3),
        'motivo_cierre':   motivo,
        'resultado_cts':   round(resultado_cts, 3),
        'resultado_usd':   round(resultado_usd, 2),
        'estado':          'CERRADO',
    }

    if client is None:
        logger.info(f"[SIN DB] Cerrar trade {trade_id}: {datos}")
        return True

    try:
        client.table('trades').update(datos).eq('id', trade_id).execute()
        logger.info(f"Trade cerrado: {motivo} | {resultado_usd:+.2f}$")
        return True
    except Exception as e:
        logger.error(f"Error cerrando trade {trade_id}: {e}")
        return False


def obtener_trades_abiertos() -> list:
    """
    Retorna todos los trades actualmente abiertos.
    """
    client = get_client()

    if client is None:
        logger.info("[SIN DB] Sin trades abiertos (no hay DB)")
        return []

    try:
        res = client.table('trades').select('*').eq('estado', 'ABIERTO').execute()
        return res.data or []
    except Exception as e:
        logger.error(f"Error obteniendo trades abiertos: {e}")
        return []


# ══════════════════════════════════════════════════════════
# RESUMEN Y ESTADÍSTICAS
# ══════════════════════════════════════════════════════════

def resumen_paper_trading() -> dict:
    """
    Calcula estadísticas del paper trading desde la DB.
    """
    client = get_client()

    if client is None:
        return {}

    try:
        res = client.table('trades').select('*').eq('estado', 'CERRADO').execute()
        trades = res.data or []

        if not trades:
            return {'trades': 0, 'mensaje': 'Sin trades cerrados aún'}

        neto  = sum(t['resultado_usd'] for t in trades)
        wins  = [t for t in trades if t['resultado_usd'] > 0]
        loss  = [t for t in trades if t['resultado_usd'] <= 0]
        tg    = sum(t['resultado_usd'] for t in wins)
        tp    = sum(abs(t['resultado_usd']) for t in loss)

        return {
            'trades':   len(trades),
            'wins':     len(wins),
            'losses':   len(loss),
            'wr':       round(len(wins) / len(trades) * 100, 1),
            'pf':       round(tg / tp, 2) if tp > 0 else 999,
            'neto':     round(neto, 2),
            'media_w':  round(tg / len(wins), 2) if wins else 0,
            'media_l':  round(-tp / len(loss), 2) if loss else 0,
        }
    except Exception as e:
        logger.error(f"Error calculando resumen: {e}")
        return {}
